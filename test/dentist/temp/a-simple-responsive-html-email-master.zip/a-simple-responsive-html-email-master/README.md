### Tuts+ Tutorial: A Simple Responsive HTML Email
#### Instructor: Nicole Merlin

In this tutorial I will show you how to create a simple responsive HTML email which will work in every email client, including all the new smartphone mail clients and apps. It uses minimal media queries and a fluid width approach to ensure maximum compatibility.

Source files for the Tuts+ tutorial: [Creating a Simple Responsive HTML Email](http://enva.to/16YygSy)

[View the demo](http://tutsplus.github.io/a-simple-responsive-html-email/HTML/index.html)
